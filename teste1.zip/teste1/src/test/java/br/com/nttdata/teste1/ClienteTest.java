package br.com.nttdata.teste1;
import org.junit.Test;
import static org.junit.Assert.*;

public class ClienteTest {

    @Test
    public void testRealizarRecarga() {
        Telefone telefone = new Telefone("123456789", 0);
        Conta conta = new Conta(100);

        telefone.setConta(conta);
        assertEquals(0, telefone.getSaldo());
        assertEquals(100, conta.getSaldo());

        telefone.realizarRecarga(50);
        assertEquals(50, telefone.getSaldo());
        assertEquals(50, conta.getSaldo());

        telefone.realizarRecarga(-20);
        assertEquals(50, telefone.getSaldo());
        assertEquals(50, conta.getSaldo());

        telefone.realizarRecarga(0);
        assertEquals(50, telefone.getSaldo());
        assertEquals(50, conta.getSaldo());

        telefone.realizarRecarga(200);
        assertEquals(50, telefone.getSaldo());
        assertEquals(50, conta.getSaldo());

    }
}
